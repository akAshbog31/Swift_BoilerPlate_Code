//
//  API.swift
//  Squeezee
//
//  Created by AKASH on 04/08/23.
//

import Foundation

enum API {
}

extension API: APIProtocol {
    var baseURL: String {
        return ""
    }
    
    var path: String {
        switch self { }
    }
    
    var method: APIMethod {
        switch self { }
    }
    
    var task: Request {
        switch self { }
    }
    
    var header: [String : String] {
        switch self { }
    }
}
