//
//  Enums.swift
//  Squeezee
//
//  Created by AKASH on 21/08/23.
//

import Foundation

enum APIError: Error {
    case badRequest(statusCode: Int)
    case decodingError
    case invalidURL(urlStr: String)
}

extension APIError: CustomStringConvertible {
    var description: String {
        switch self {
        case .badRequest(let statusCode):
            return "Bad url request, Status code: - \(statusCode)."
        case .decodingError:
            return "Model can not decodable."
        case .invalidURL(let urlStr):
            return "URL is invalid, current url is \(urlStr)."
        }
    }
}

enum APIMethod: String {
    case get, post, put, patch, delete
}

enum Request {
    case jsonEncoding(_ model: [String: Any]?)
    case queryString(_ dict: [String: Any]?)
    case none
    
    var jsonBody: [String: Any]? {
        switch self {
        case .jsonEncoding(let model):
            return model
        case .queryString, .none: return nil
        }
    }
    
    var queryItem: [URLQueryItem] {
        switch self {
        case .jsonEncoding, .none:
            return []
        case .queryString(let dict):
            return dict?.asQueryParam ?? []
        }
    }
}
