//
//  MainCell.swift
//  BoilerPlate
//
//  Created by AKASH on 21/11/23.
//

import UIKit

final class MainCell: UICollectionViewCell {
    //MARK: - @IBOutlet
    
    //MARK: - Properties
    
    //MARK: - LifeCycle
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    //MARK: - @IBAction
    
    //MARK: - Functions
}
