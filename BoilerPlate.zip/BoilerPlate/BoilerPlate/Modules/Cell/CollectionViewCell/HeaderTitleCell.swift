//
//  HeaderTitleCell.swift
//  KarmaScore
//
//  Created by iOS Developer on 09/11/23.
//

import UIKit

final class HeaderTitleCell: UICollectionViewCell {
    //MARK: - @IBOutlet
    @IBOutlet weak var lblTitle: UILabel!
    
    //MARK: - Properties
    
    //MARK: - LifeCycle
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    //MARK: - @IBAction
    
    //MARK: - Functions
}
