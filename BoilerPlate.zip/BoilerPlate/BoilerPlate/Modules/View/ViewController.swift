//
//  ViewController.swift
//  BoilerPlate
//
//  Created by AKASH on 21/11/23.
//

import UIKit

final class ViewController: BaseVc {
    //MARK: - @IBOutlet
    @IBOutlet weak var clvMain: UICollectionView!
    
    //MARK: - Properties
    
    //MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func setUi() {
        super.setUi()
        
        clvMain.delegate = self
        clvMain.dataSource = self
        clvMain.register(R.nib.headerTitleCell, forSupplementaryViewOfKind: "Header")
        clvMain.register(R.nib.mainCell)
        configureCollectionView()
    }
    
    //MARK: - @IBAction
    
    //MARK: - Functions
    private func configureCollectionView() {
        let layout = UICollectionViewCompositionalLayout { sectionIndex, enviroment in
            switch sectionIndex {
            case 0 : return AppLayout.shared.appSection()
            case 1 : return AppLayout.shared.appSection()
            default: return AppLayout.shared.appSection()
            }
        }
        clvMain.setCollectionViewLayout(layout, animated: true)
    }
}

//MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case 0: return 3
        case 1: return 6
        default: return 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch indexPath.section {
        case 0:
            let cell: MainCell = collectionView.deque(indexPath: indexPath)
            return cell
        case 1:
            let cell: MainCell = collectionView.deque(indexPath: indexPath)
            return cell
        default:
            let cell: MainCell = collectionView.deque(indexPath: indexPath)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == "Header" {
            guard let header = clvMain.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: R.nib.headerTitleCell, for: indexPath) else { return .init() }
            switch indexPath.section {
            case 0:
                header.lblTitle.text = "Top Relationship"
            case 1:
                header.lblTitle.text = "Overview"
            default:
                header.lblTitle.text = "Top Relationship"
            }
            return header
        }
        return UICollectionReusableView()
    }
}

