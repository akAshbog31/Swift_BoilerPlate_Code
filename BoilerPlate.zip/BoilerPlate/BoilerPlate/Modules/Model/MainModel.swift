//
//  MainModel.swift
//  BoilerPlate
//
//  Created by AKASH on 21/11/23.
//

import Foundation

//MARK: - MainModel
struct MainModel {
    
}
